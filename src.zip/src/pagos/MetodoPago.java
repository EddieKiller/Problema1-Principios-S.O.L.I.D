package pagos;

public interface MetodoPago {
    boolean procesarPago(double monto);
}
